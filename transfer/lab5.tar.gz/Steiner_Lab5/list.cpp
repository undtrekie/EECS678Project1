#include "list.h"

//Constructor
list::list(){
  m_front=nullptr;
  m_back=nullptr;
}

//Deconstructor
list::~list(){
  while(!isEmpty()){
    o_node* temp = m_front;
    m_front = m_front->getNext();
    delete temp;
  }
}

//insert given value at end of list
void list::insert(int val){
  //no nodes in list yet 
  if(m_front==nullptr){
    o_node* newnode = new o_node();
    newnode->setValue(val);
    m_front=newnode;
    m_back=newnode;
  }
  //nodes already exist in list
  else{
    o_node* exists = Find_p(val, m_front);
    if(exists==nullptr){
      o_node* newnode = new o_node();
      newnode->setValue(val);
      m_back->setNext(newnode);
      m_back=newnode;
    }
  }
}

//Find if list is empty
bool list::isEmpty(){
  if(m_front==nullptr)
    return true;
  else
    return false;
}

//Erase given value (and delete associated node)
void list::erase(int x){
  o_node* toRemove = Find_p(x, m_front);
  //if not in list
  if(toRemove==nullptr){
    std::cout<<"That number is not in the list"<<std::endl;
  }
  //if in list and at front
  else if(m_front==toRemove){
    m_front=toRemove->getNext();
    delete toRemove;
  }
  //if in list and in between two nodes
  else if(toRemove!=m_back && toRemove!=m_front){
    o_node* previous=m_front;
    o_node* next=toRemove->getNext();
    //get previous node
    while(previous->getNext()!=toRemove){
      previous=previous->getNext();
    }
    previous->setNext(next);
    delete toRemove;
  }
  //if in list and at end
  else if(toRemove==m_back){
    o_node* previous=m_front;
    //get previous node
    while(previous->getNext()!=toRemove){
      previous=previous->getNext();
    }
    delete m_back;
    m_back=previous;
    m_back->setNext(nullptr);
  }
}

//prints off list
void list::print(){
  if(!isEmpty()){
    std::cout<<m_front->getValue()<<"  ";
    o_node* temp=m_front->getNext();
    while(temp!=nullptr){
      std::cout<<temp->getValue()<<"  ";
      temp=temp->getNext();
    }
    std::cout<<"\n";
  }
  else{

    std::cout<<"\n";
  }
}

//Private function to check if node with value in list
o_node* list::Find_p(int x, o_node* curr){
  if (curr==nullptr)
    return nullptr;
  else if (curr->getValue()==x)
    return curr;
  else
    return Find_p(x, curr->getNext());
}

//Public function to find if node in list
o_node* list::Find(int x){
	return Find_p(x, m_front);
}
