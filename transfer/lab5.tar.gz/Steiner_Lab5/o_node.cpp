/**
 *@file : o_node.cpp
 *@author :  Tyler Steiner
 *@date : 2015.01.26
 *Purpose: Defines and implements node class
 */
#include "o_node.h"

o_node::o_node(){
	//initial int value
	m_value=0;
	//pointer to next in list
	m_next=nullptr;
}	
int o_node::getValue(){
  return m_value;
}

o_node* o_node::getNext(){
  return m_next;
}

void o_node::setValue(int val){
  m_value=val;
}
void o_node::setNext(o_node* next){
  m_next=next;
}
