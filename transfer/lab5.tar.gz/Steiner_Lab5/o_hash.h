/**
 *@file : o_hash.h
 *@author : Tyler Steiner
 *@date : 2014.01.26
 *@Purpose : Header file of o_hash class
 */
#ifndef O_HASH_H
#define O_HASH_H

#include <iostream>
#include <string>
#include "list.h"
#include "o_node.h"

class o_hash{
    private:
        list** table;
        int size;
        
    public:
        o_hash(int x);
        ~o_hash();
        void insert(int x);
        void rem(int x);
        void print();
        int hashv(int x);
        bool find(int x);
    
};
#endif
