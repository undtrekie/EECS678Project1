/**
 *@file : c_hash.h
 *@author : Tyler Steiner
 *@date : 2014.02.14
 *@Purpose : Header file of c_hash class
 */
#ifndef C_HASH_H
#define C_HASH_H

#include <iostream>
#include <string>
#include "c_node.h"

class c_hash{
    private:
		//variables of closed hash class
        c_node** table;
        int size;
		int inserts;
        int noInsert;
    public:
		/**
   		*  @pre None
   		*  @post Creates and initializes a hash table
   		*  @return hash table given size
   		*/
        c_hash(int x);
		/**
   		*  @pre Initialized hash table
   		*  @post Deconstructs and deletes hash table
   		*  @return None
   		*/
        ~c_hash();
		/**
   		*  @pre Initialized Hash Table
   		*  @post Inserts given number in hash table
   		*  @return None if successful, error msg if not
   		*/
        void insert(int x);
		/**
   		*  @pre Initialized hash table
   		*  @post Removes given number from hash table
   		*  @return None if successful, error msg if not
   		*/
        void remove(int x);
		/**
   		*  @pre Initialized hash table
   		*  @post Prints values in hash table + flag values
   		*  @return None
   		*/
        void print();
		/**
   		*  @pre Initialized Hash Table
   		*  @post Calcluates Hash Value + i for quadratic hashing
   		*  @return Hash Value
   		*/
        int hashv(int x, int i);
		/**
   		*  @pre Initialized hash table
   		*  @post Checks hash table for value
   		*  @return True if in table, false otherwise
   		*/
        bool contains(int x);
		/**
   		*  @pre Initialized Hash table
   		*  @post Checks to see if hash table is full
   		*  @return True if full, false otherwise
   		*/
		bool isFull();

		int nonDupFailed();
    
};
#endif
