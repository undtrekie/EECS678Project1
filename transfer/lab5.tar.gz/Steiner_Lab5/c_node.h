/**
 *@file : c_node.h
 *@author :  Tyler Steiner
 *@date : 2015.02.14
 *Purpose: Header file of node class
 */

#ifndef C_NODE_H
#define C_NODE_H
class c_node{
        private:
		//variables of node class
		int m_value;
		bool m_flag;
	public:
		/**
   		*  @pre None
   		*  @post Creates and initializes a node
   		*  @return One node w/ values initialized to m_value=0, m_next=nullptr
   		*/
		c_node();

		/**
   		*  @pre Initialized Node
   		*  @post Gets Value of node
   		*  @return Returns value of node
   		*/
		int getValue();

		/**
   		*  @pre Initialized Node
   		*  @post Gets next node
   		*  @return Returns ptr to next node in list
   		*/
		bool getFlag();

		/**
   		*  @pre Initialized Node
   		*  @post Sets value of node
   		*  @return None
   		*/
		void setValue(int val);

		/**
   		*  @pre Initialized Node
   		*  @post Sets ptr to next node
   		*  @return None
   		*/
		void setFlag(bool flag);
};
#endif
