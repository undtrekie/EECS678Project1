/**
 *@file : c_node.cpp
 *@author :  Tyler Steiner
 *@date : 2015.01.26
 *Purpose: Defines and implements node class
 */
#include "c_node.h"

c_node::c_node(){
	//initial int value
	m_value=-1;
	//pointer to next in list
	m_flag=false;
}	
int c_node::getValue(){
  return m_value;
}

bool c_node::getFlag(){
  return m_flag;
}

void c_node::setValue(int val){
  m_value=val;
}
void c_node::setFlag(bool flag){
  m_flag=flag;
}
