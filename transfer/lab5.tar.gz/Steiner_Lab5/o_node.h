/**
 *@file : o_node.h
 *@author :  Tyler Steiner
 *@date : 2015.01.26
 *Purpose: Header file of node class
 */

#ifndef O_NODE_H
#define O_NODE_H
class o_node{
        private:
  int m_value;
  o_node* m_next;
	public:
		//variables for node of linked list
		/**
   		*  @pre None
   		*  @post Creates and initializes a node
   		*  @return One node w/ values initialized to m_value=0, m_next=nullptr
   		*/
		o_node();

		/**
   		*  @pre Initialized Node
   		*  @post Gets Value of node
   		*  @return Returns value of node
   		*/
		int getValue();

		/**
   		*  @pre Initialized Node
   		*  @post Gets next node
   		*  @return Returns ptr to next node in list
   		*/
		o_node* getNext();

		/**
   		*  @pre Initialized Node
   		*  @post Sets value of node
   		*  @return None
   		*/
		void setValue(int val);

		/**
   		*  @pre Initialized Node
   		*  @post Sets ptr to next node
   		*  @return None
   		*/
		void setNext(o_node* next);
};
#endif
