/**
 *@file : list.h
 *@author : Tyler Steiner
 *@date : 2014.01.26
 *@Purpose : Header file of list class
 */
#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <string>
#include "o_node.h"
class list{
	private:
		o_node* m_front;
		o_node* m_back;

		/**
		* @pre Initialized linked list
		* @post Finds node with given value
		* @return ptr to node with value
		*/
		o_node* Find_p(int x, o_node* curr);

	public:
		/**
		* @pre None
		* @post Creates and initializes a linked list of nodes
		* @return Initialized linked list
		*/
		list();

		/**
		* @pre initialized list
		* @post Deletes all nodes
		* @return None
		*/
		~list();

		/**
		* @pre Initialized linked list
		* @post Inserts value at end of list
		* @return None
		*/
		void insert(int value);

		/**
		* @pre Initialized linked list
		* @post Checks if list is empty
		* @return Returns true if empty/false otherwise
		*/
		bool isEmpty();

		/**
		* @pre Initialized linked list
		* @post Deletes node with given value or gives error
		* @return None
		*/
		void erase(int x);
		
		/**
		* @pre Initialized linked list
		* @post Prints values of list in order
		* @return None
		*/
		void print();

		/**
		* @pre Initialized linked list
		* @post Finds node with given value
		* @return ptr to node with value
		*/
		o_node* Find(int x);

};
#endif
	
