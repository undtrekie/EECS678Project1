#include <stdlib.h>
#include "Timer.cpp"
#include "c_hash.h"
#include "o_hash.h"
#include <iostream>


int main(int argc, char* argv[]){
	double lfs[]={0.2, 0.3, 0.4, 0.5, 0.6};
	int load;
	o_hash* ohash;
	c_hash* chash;	
	Timer* t = new Timer();
	double o_time, c_time;
	
	for(int i=1; i<=5; i++){
	    for(int k=0; k<5; k++){
		ohash=new o_hash(600011);
		chash=new c_hash(600011);
		srand(k);
		load=lfs[i-1]*600011;
		long data[load];
		for(int j=0; j<load; j++){
			data[j]=rand();
			if(data[j]<0)
				data[j]*-1;
		}

		t->start();
		for(int j=0; j<load; j++){
			ohash->insert(data[j]);
		}
		o_time=t->stop();

		t->start();
		for(int j=0; j<load; j++){
			chash->insert(data[j]);
		}
		c_time=t->stop();
		//std::cout<<data[load-1]<<"; "<<chash->contains(data[load-1])<<std::endl;

		std::cout<<"Load Factor: "<<lfs[i-1]<<std::endl;
		std::cout<<"Open Hashing Time: "<<o_time<<std::endl;
		std::cout<<"Closed Hashing Time: "<<c_time<<std::endl;
		std::cout<<"\n";
		delete ohash, chash;
		}
	}

	delete t;
	return 0;
}
