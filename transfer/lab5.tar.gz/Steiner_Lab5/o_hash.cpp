#include "o_hash.h"


o_hash::o_hash(int x){
    size=x;
    table = new list* [size];
    for(int i=0; i<size; i++){
        table[i]=new list();
    }
}
o_hash::~o_hash(){
    for(int i=0; i<size; i++){
        delete table[i];
    }
    delete[] table;
}
void o_hash::insert(int x){
	int hval=hashv(x);
	table[hval]->insert(x);
}
void o_hash::rem(int x){
    int hval=hashv(x);
	table[hval]->erase(x);
}
void o_hash::print(){
	std::cout<<"\n";
    for(int i=0; i<size; i++){
		std::cout<<i<<": ";
		table[i]->print();
	}
}
int o_hash::hashv(int x){
    return x%size;
}
bool o_hash::find(int x){
    int hval=hashv(x);
	o_node* test = table[hval]->Find(x);
	if(test==nullptr)
		return false;
	else
		return true;
}
