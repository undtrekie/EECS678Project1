#include "c_hash.h"

c_hash::c_hash(int x){
    size=x;
	inserts=0;
	noInsert=0;
    table = new c_node* [size];
    for(int i=0; i<size; i++){
        table[i]=new c_node();
    }
}
c_hash::~c_hash(){
    for(int i=0; i<size; i++){
        delete table[i];
    }
    delete[] table;
}
void c_hash::insert(int x){
	int i=0;
	bool success=false;
	if(!contains(x))
	{
		while(!success && i<=size){
			int hval=hashv(x, i);
			if(i>=size){
				std::cout<<"Number cannot be inserted."<<std::endl;
				noInsert++;
				std::cout<<noInsert<<" ";
				success=true;
			}
			else if(table[hval]->getValue() == -1){
				table[hval]->setValue(x);
				success=true;
				inserts++;
				table[hval]->setFlag(false);
			}
			else{
				i++;
			}
		}
	}else{
		//std::cout<<"Number already exists and cannot be inserted."<<std::endl;
	}
}
void c_hash::remove(int x){
	//std::cout<<contains(x)<<std::endl;
	if(contains(x)){
		bool success=false;
		int i=0;
		int hval;
		while(!success){
			hval=hashv(x, i);
			if(table[hval]->getValue() == x){
				//std::cout<<"HERE\n";
				table[hval]->setFlag(true);
				table[hval]->setValue(-1);
				success=true;
				inserts--;
			}else{
				i++;
			}
		}
	}
}
void c_hash::print(){
	std::cout<<"\n";
    for(int i=0; i<size; i++){
		std::cout<<i<<": "<<table[i]->getValue();
		if(table[i]->getFlag()){
			std::cout<<" flag = true"<<std::endl;
		}else{
			std::cout<<" flag = false"<<std::endl;
		}
	}
	std::cout<<"\n";
}
int c_hash::hashv(int x, int i){
    return (x%size+(i*i))%size;
}
bool c_hash::contains(int x){
	int i=0;
	int hval;
	int value;
	while(i<size){
		hval=hashv(x, i);
		value=table[hval]->getValue();
		if(value==x){//match
			//std::cout<<"Match! i:"<<i<<std::endl;
			return true;
		}else if(value==-1 && table[hval]->getFlag()==false){//not
			//std::cout<<"No Match! i:"<<i<<std::endl;
			return false;
		}else{//some other value
			i++;
		}
	}
}
bool c_hash::isFull(){
	return (inserts>=size);	
}

int c_hash::nonDupFailed(){
	return noInsert;
}
